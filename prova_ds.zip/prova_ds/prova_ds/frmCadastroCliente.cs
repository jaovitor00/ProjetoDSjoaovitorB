﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prova_ds
{
    public partial class frmCadastroCliente : Form
    {
        public frmCadastroCliente()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void frmCadastroCliente_Load(object sender, EventArgs e)
        {

        }

        private void BTNcadastro_Click(object sender, EventArgs e)


        {
            TXTnome.Enabled = false;
            TXTcpf.Enabled = false;
            TXTidade.Enabled = false;
            TXTendereco.Enabled = false;
            TXTcidade.Enabled = false;
            TXTtelefone.Enabled = false;
            TXTemail.Enabled = false;
            TXTnome.Focus();




            MySqlConnection conn = new MySqlConnection("server=localhost;database=bdlivraria;uid=root;pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;
            comando.CommandText = ("insert into cliente (nome,cpf,idade,endereco,cidade,telefone,email) values (@nome,@cpf,@idade,@endereco,@cidade,@telefone,@email)");
            comando.Parameters.AddWithValue("@nome", TXTnome.Text);
            comando.Parameters.AddWithValue("@cpf", TXTcpf.Text);
            comando.Parameters.AddWithValue("@idade", TXTidade.Text);
            comando.Parameters.AddWithValue("@endereco", TXTendereco.Text);
            comando.Parameters.AddWithValue("@cidade", TXTcidade.Text);
            comando.Parameters.AddWithValue("@telefone", TXTtelefone.Text);
            comando.Parameters.AddWithValue("@email", TXTemail.Text);
            conn.Open();
            _ = comando.ExecuteNonQuery();
            MessageBox.Show("CADASTRO COMPLETO");
        }

        private void BTNsalvar_Click(object sender, EventArgs e)
        {
            TXTnome.Enabled = true;
            TXTcpf.Enabled = true;
            TXTidade.Enabled = true;
            TXTendereco.Enabled = true;
            TXTcidade.Enabled = true;
            TXTtelefone.Enabled = true;
            TXTemail.Enabled = true;
            TXTnome.Focus();


        }
    }
}
