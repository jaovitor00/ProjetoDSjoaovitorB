﻿
namespace prova_ds
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BTNusuario = new System.Windows.Forms.Button();
            this.BTNlogin = new System.Windows.Forms.Button();
            this.BTNsair = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::prova_ds.Properties.Resources.MENU__2_;
            this.pictureBox1.Location = new System.Drawing.Point(12, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(808, 435);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // BTNusuario
            // 
            this.BTNusuario.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BTNusuario.Location = new System.Drawing.Point(29, 126);
            this.BTNusuario.Name = "BTNusuario";
            this.BTNusuario.Size = new System.Drawing.Size(151, 60);
            this.BTNusuario.TabIndex = 1;
            this.BTNusuario.Text = "USUARIO";
            this.BTNusuario.UseVisualStyleBackColor = false;
            this.BTNusuario.Click += new System.EventHandler(this.BTNusuario_Click);
            // 
            // BTNlogin
            // 
            this.BTNlogin.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BTNlogin.Location = new System.Drawing.Point(29, 216);
            this.BTNlogin.Name = "BTNlogin";
            this.BTNlogin.Size = new System.Drawing.Size(151, 60);
            this.BTNlogin.TabIndex = 2;
            this.BTNlogin.Text = "LOGIN";
            this.BTNlogin.UseVisualStyleBackColor = false;
            this.BTNlogin.Click += new System.EventHandler(this.BTNlogin_Click);
            // 
            // BTNsair
            // 
            this.BTNsair.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BTNsair.Location = new System.Drawing.Point(29, 300);
            this.BTNsair.Name = "BTNsair";
            this.BTNsair.Size = new System.Drawing.Size(151, 60);
            this.BTNsair.TabIndex = 3;
            this.BTNsair.Text = "SAIR";
            this.BTNsair.UseVisualStyleBackColor = false;
            this.BTNsair.Click += new System.EventHandler(this.BTNsair_Click);
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(842, 450);
            this.Controls.Add(this.BTNsair);
            this.Controls.Add(this.BTNlogin);
            this.Controls.Add(this.BTNusuario);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmMenu";
            this.Text = "frmMenu";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BTNusuario;
        private System.Windows.Forms.Button BTNlogin;
        private System.Windows.Forms.Button BTNsair;
    }
}