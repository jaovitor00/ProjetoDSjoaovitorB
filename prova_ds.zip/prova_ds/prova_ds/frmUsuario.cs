﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace prova_ds
{
    public partial class frmUsuario : Form
    {
        public frmUsuario()
        {
            InitializeComponent();
        }

        private void frmUsuario_Load(object sender, EventArgs e)
        {
            txtName.Enabled = false;
            txtPassoword.Enabled = false;
           

        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {

            String login;
            MySqlDataReader reg = null;
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bdlivraria;uid=root;pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;

            comando.CommandText = "select * from usuario where login =@login and senha= @senha";
            comando.Parameters.AddWithValue("@login", txtName.Text);
            comando.Parameters.AddWithValue("@senha", txtPassoword.Text);
            conn.Open();
            reg = comando.ExecuteReader();
            if (reg.Read())
                {
                login = reg["login"].ToString();
                MessageBox.Show("Usuário logado"); 
                frmMenu menu = new frmMenu();
                menu.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Usuário não encontrado");
                txtName.Text = "";
                txtPassoword.Text = "";
                txtPassoword.Focus();
            }

        }

        private void BTNliberar_Click(object sender, EventArgs e)
        {
            txtName.Enabled = true;
            txtPassoword.Enabled = true;
            btnEntrar.Enabled = true;
            txtName.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
          
            frmMenu usu = new frmMenu();
            usu.Show();
            Hide();

        }
    }
}
