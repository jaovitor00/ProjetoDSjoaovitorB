﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using MySql.Data.MySqlClient;


namespace prova_ds
{
    public partial class frmCadastro : Form
    {
        public frmCadastro()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            txtNome.Enabled = true;
            txtSenha.Enabled = true;
            btnEntrar.Enabled = true;
            txtNome.Focus();


        }

        private void frmCadastro_Load(object sender, EventArgs e)
        {
            txtNome.Enabled = false;
            txtSenha.Enabled = false;

        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bdlivraria;uid=root;pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;
            comando.CommandText = ("insert into usuario(login,senha) values (@login,@senha)");
            comando.Parameters.AddWithValue("@login", txtNome.Text);
            comando.Parameters.AddWithValue("@senha", txtSenha.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("usuario inserido com sucesso");

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            frmMenu usu = new frmMenu();
            usu.Show();
            Hide();
        }
    }
    
}
