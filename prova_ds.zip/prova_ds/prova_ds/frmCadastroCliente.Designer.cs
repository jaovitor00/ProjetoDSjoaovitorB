﻿
namespace prova_ds
{
    partial class frmCadastroCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BTNcadastro = new System.Windows.Forms.Button();
            this.TXTnome = new System.Windows.Forms.TextBox();
            this.TXTidade = new System.Windows.Forms.TextBox();
            this.TXTcpf = new System.Windows.Forms.TextBox();
            this.TXTendereco = new System.Windows.Forms.TextBox();
            this.TXTemail = new System.Windows.Forms.TextBox();
            this.TXTtelefone = new System.Windows.Forms.TextBox();
            this.TXTcidade = new System.Windows.Forms.TextBox();
            this.BTNnovo = new System.Windows.Forms.Button();
            this.BTNlimpar = new System.Windows.Forms.Button();
            this.BTNconsulta = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::prova_ds.Properties.Resources.Blue_Flat_Color_UI_Login_Page_Desktop_Prototype__1_;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(801, 456);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BTNcadastro
            // 
            this.BTNcadastro.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BTNcadastro.Location = new System.Drawing.Point(398, 411);
            this.BTNcadastro.Name = "BTNcadastro";
            this.BTNcadastro.Size = new System.Drawing.Size(92, 47);
            this.BTNcadastro.TabIndex = 1;
            this.BTNcadastro.Text = "CADASTRAR CLIENTE";
            this.BTNcadastro.UseVisualStyleBackColor = false;
            this.BTNcadastro.Click += new System.EventHandler(this.BTNcadastro_Click);
            // 
            // TXTnome
            // 
            this.TXTnome.Location = new System.Drawing.Point(438, 66);
            this.TXTnome.Multiline = true;
            this.TXTnome.Name = "TXTnome";
            this.TXTnome.Size = new System.Drawing.Size(223, 35);
            this.TXTnome.TabIndex = 2;
            // 
            // TXTidade
            // 
            this.TXTidade.Location = new System.Drawing.Point(438, 167);
            this.TXTidade.Multiline = true;
            this.TXTidade.Name = "TXTidade";
            this.TXTidade.Size = new System.Drawing.Size(223, 35);
            this.TXTidade.TabIndex = 3;
            // 
            // TXTcpf
            // 
            this.TXTcpf.Location = new System.Drawing.Point(438, 116);
            this.TXTcpf.Multiline = true;
            this.TXTcpf.Name = "TXTcpf";
            this.TXTcpf.Size = new System.Drawing.Size(223, 35);
            this.TXTcpf.TabIndex = 4;
            // 
            // TXTendereco
            // 
            this.TXTendereco.Location = new System.Drawing.Point(438, 217);
            this.TXTendereco.Multiline = true;
            this.TXTendereco.Name = "TXTendereco";
            this.TXTendereco.Size = new System.Drawing.Size(223, 35);
            this.TXTendereco.TabIndex = 5;
            // 
            // TXTemail
            // 
            this.TXTemail.Location = new System.Drawing.Point(438, 367);
            this.TXTemail.Multiline = true;
            this.TXTemail.Name = "TXTemail";
            this.TXTemail.Size = new System.Drawing.Size(223, 38);
            this.TXTemail.TabIndex = 6;
            // 
            // TXTtelefone
            // 
            this.TXTtelefone.Location = new System.Drawing.Point(438, 316);
            this.TXTtelefone.Multiline = true;
            this.TXTtelefone.Name = "TXTtelefone";
            this.TXTtelefone.Size = new System.Drawing.Size(223, 35);
            this.TXTtelefone.TabIndex = 7;
            // 
            // TXTcidade
            // 
            this.TXTcidade.Location = new System.Drawing.Point(438, 268);
            this.TXTcidade.Multiline = true;
            this.TXTcidade.Name = "TXTcidade";
            this.TXTcidade.Size = new System.Drawing.Size(223, 32);
            this.TXTcidade.TabIndex = 8;
            // 
            // BTNnovo
            // 
            this.BTNnovo.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BTNnovo.Location = new System.Drawing.Point(487, 411);
            this.BTNnovo.Name = "BTNnovo";
            this.BTNnovo.Size = new System.Drawing.Size(87, 47);
            this.BTNnovo.TabIndex = 9;
            this.BTNnovo.Text = "LIBERAR";
            this.BTNnovo.UseVisualStyleBackColor = false;
            this.BTNnovo.Click += new System.EventHandler(this.BTNsalvar_Click);
            // 
            // BTNlimpar
            // 
            this.BTNlimpar.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BTNlimpar.Location = new System.Drawing.Point(574, 411);
            this.BTNlimpar.Name = "BTNlimpar";
            this.BTNlimpar.Size = new System.Drawing.Size(87, 47);
            this.BTNlimpar.TabIndex = 10;
            this.BTNlimpar.Text = "LIMPAR";
            this.BTNlimpar.UseVisualStyleBackColor = false;
            // 
            // BTNconsulta
            // 
            this.BTNconsulta.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BTNconsulta.Location = new System.Drawing.Point(657, 411);
            this.BTNconsulta.Name = "BTNconsulta";
            this.BTNconsulta.Size = new System.Drawing.Size(87, 47);
            this.BTNconsulta.TabIndex = 11;
            this.BTNconsulta.Text = "CONSULTAR";
            this.BTNconsulta.UseVisualStyleBackColor = false;
            // 
            // frmCadastroCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 462);
            this.Controls.Add(this.BTNconsulta);
            this.Controls.Add(this.BTNlimpar);
            this.Controls.Add(this.BTNnovo);
            this.Controls.Add(this.TXTcidade);
            this.Controls.Add(this.TXTtelefone);
            this.Controls.Add(this.TXTemail);
            this.Controls.Add(this.TXTendereco);
            this.Controls.Add(this.TXTcpf);
            this.Controls.Add(this.TXTidade);
            this.Controls.Add(this.TXTnome);
            this.Controls.Add(this.BTNcadastro);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmCadastroCliente";
            this.Text = "frmCadastroCliente";
            this.Load += new System.EventHandler(this.frmCadastroCliente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BTNcadastro;
        private System.Windows.Forms.TextBox TXTnome;
        private System.Windows.Forms.TextBox TXTidade;
        private System.Windows.Forms.TextBox TXTcpf;
        private System.Windows.Forms.TextBox TXTendereco;
        private System.Windows.Forms.TextBox TXTemail;
        private System.Windows.Forms.TextBox TXTtelefone;
        private System.Windows.Forms.TextBox TXTcidade;
        private System.Windows.Forms.Button BTNnovo;
        private System.Windows.Forms.Button BTNlimpar;
        private System.Windows.Forms.Button BTNconsulta;
    }
}