﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prova_ds
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void BTNusuario_Click(object sender, EventArgs e)
        {
            frmCadastro usu = new frmCadastro();
            usu.Show();
            Hide();
         
        }

        private void BTNsair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BTNlogin_Click(object sender, EventArgs e)
        {
            frmUsuario usu = new frmUsuario();
            usu.Show();
            Hide();
        }
    }
}
